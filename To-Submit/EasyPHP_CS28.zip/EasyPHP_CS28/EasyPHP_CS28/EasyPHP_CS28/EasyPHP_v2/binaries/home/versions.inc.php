<?php
/**
 * EasyPHP: a complete WAMP environement for PHP development & personal
 * web hosting including PHP, Apache, MySQL, PhpMyAdmin, Xdebug...
 * DEVSERVER for PHP development and WEBSERVER for personal web hosting
 * @author   Laurent Abbal <laurent@abbal.com>
 * @link     http://www.easyphp.org
 */

$version_easyphp = "14.1";
$version_apache = "2.4.7";
$version_php = "5.5.8 VC11";
$version_mysql = "5.6.15";
$version_phpmyadmin = "4.1.4";
$version_xdebug = "2.2.3";
?>