<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8" />
	<title>Staff Portal</title>
    <style>
        h1 {
            text-align: center;
            font-family: Calibri;
        }
        p.p-centre {
            text-align: center;
            font-family: Arial;
        }
        .buttons {
          display: flex;
          justify-content: center;
        }

				#nav { font-family: Arial; font-size: 14px; width: 100%; float: left; margin: 0 0 1em 0; padding: 0; list-style: none;}
				#nav {list-style: none; border:0;}
				#rightnav { list-style: none; }
				#nav li { float: left; }
				#rightnav li { float: right; }
				#nav li a { margin: 0 3px 0 0; font-size: 15px; display: block; padding: 8px 15px; text-decoration: none; color: #000; background-color: #f2f2f2; border: 1px solid #c1c1c1;}
				#nav li a:hover {background-color: #f2e4d5;}
				#nav a:link, a:visited {border-radius: 12px 12px 12px 12px; }		
    </style>

	<?php 
		foreach($css_files as $file): ?>
		<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
	<?php endforeach; ?>

	<?php foreach($js_files as $file): ?>
		<script src="<?php echo $file; ?>"></script>
	<?php endforeach; ?>
</head>

<div class = "nav">
		<ul id="nav">
			<li><a href='<?php echo site_url('')?>'>Home</a></li>
			<li><a href='<?php echo site_url('main/cinema_sys')?>'>Cinema</a></li>
			<li><a href='<?php echo site_url('main/screen_sys')?>'>Screen</a></li>
			<li><a href='<?php echo site_url('main/member_sys')?>'>Member</a></li>
			<li><a href='<?php echo site_url('main/film_sys')?>'>Film</a></li>

				<li><a href='<?php echo site_url('main/booking_sys')?>'>Booking</a></li>
				<li><a href='<?php echo site_url('main/performance_sys')?>'>Performance</a></li>
				<ul id="rightnav">
			<li><a href='<?php echo site_url('main/help')?>'>Help</a></li>
			</ul>
		</ul>
</div>

<body>
	<h1>Film System for Staff</h1>
	<p class="p-centre">20th - 26th June 2019 </p>
	<?php echo $output; ?>
</body>
</html>
