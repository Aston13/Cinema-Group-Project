<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8" />
	<title>Member's portal</title>
    <style>
        h1 {
            text-align: center;
            font-family: Calibri;
        }
        p.p-centre {
            text-align: center;
            font-family: Arial;
        }
        .buttons {
          display: flex;
          justify-content: center;
        }
				#nav { font-family: Arial; font-size: 14px; width: 100%; margin: 0 0 1em 0; padding: 0; list-style: none;}
				#nav {list-style: none; border:0;}
				#rightnav { list-style: none; }
				#nav li { float: left; }
				#nav li a { margin: 0 3px 0 0; font-size: 15px; display: block; padding: 8px 15px; text-decoration: none; color: #000; background-color: #f2f2f2; border: 1px solid #c1c1c1;}
				#nav li a:hover {background-color: #f2e4d5;}
				#nav a:link, a:visited {border-radius: 12px 12px 12px 12px; }		
    </style>
</head>

<body>
	<h1>Member View</h1>
	<p class="p-centre">This is what a member will see once logged in.</p>

	<div class = "nav">
		<ul id="nav">
			<li><a href='<?php echo site_url('')?>'>Home</a></li>
			<li><a href='<?php echo site_url('main/cinema_sys')?>'>Cinema</a></li>
			<li><a href='<?php echo site_url('main/screen_sys')?>'>Screen</a></li>
			<li><a href='<?php echo site_url('main/film')?>'>Film</a></li>
			<li><a href='<?php echo site_url('main/booking')?>'>Booking</a></li>
			<li><a href='<?php echo site_url('main/performance')?>'>Performance</a></li>
		</ul>
</div>

</body>
</html>