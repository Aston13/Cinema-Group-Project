<?php
    include('login.php'); // Includes Login Script

    if(isset($_SESSION['login_user'])){
        site_url('mice/index.php/main/staff_view.php'); // Redirecting To staff page
    }
?> 

<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8" />
	<title>Cinema System</title>
    <style>
        h1 {
            text-align: center;
            font-family: Calibri;
        }
        p.p-centre {
            text-align: center;
            font-family: Arial;
        }
        .buttons {
          display: flex;
          justify-content: center;
        }
    </style>
</head>

<body>
    <h1>Old 1940s Film Festival</h1>
    <p class="p-centre">20th - 26th June 2019 </p>
    <p class="p-centre">Click below to login.</p>

    <div class = buttons>
        <button><a href='<?php echo site_url('main/member_view')?>'>Member</a></button>
        <button><a href='<?php echo site_url('main/staff_view')?>'>Staff</a></button>
    </div>

    <div id="login">
        <h2>Login Form</h2>
            <form action="" method="post">
                <label>UserName :</label>
                <input id="name" name="username" placeholder="username" type="text">
                <label>Password :</label>
                <input id="password" name="password" placeholder="**********" type="password"><br><br>
                <input name="submit" type="submit" value=" Login ">
                <span><?php echo $error; ?></span>
            </form>
    </div>
</body>
</html>