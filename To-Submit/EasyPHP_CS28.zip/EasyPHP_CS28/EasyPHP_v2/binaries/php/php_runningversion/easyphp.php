<?php
$phpversion = array();
$phpversion = array(
	"status"	=> "0",
	"dirname"	=> "php558x150903144408",
	"name" 		=> "PHP",
	"version" 	=> "5.5.8",
	"date" 		=> "2015-09-03 14:44:08",
	"notes" 	=> "",
);
?>
